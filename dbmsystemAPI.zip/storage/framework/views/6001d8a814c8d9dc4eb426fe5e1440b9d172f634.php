<?php $__env->startSection('content'); ?>
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Appointments</h4>
                    </div>
                    <div class="col-sm-8 col-9 text-right m-b-20">
                        <a href="<?php echo e(route('add_hospital')); ?>" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Hospital</a>
                    </div>
                </div>
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table class="table table-striped custom-table">
								<thead>
									<tr>
										<th>#</th>
										<th>Name</th>
										<th>location</th>
										<th class="text-right">Action</th>
									</tr>
								</thead>
								<tbody>
                                    <?php $__currentLoopData = $Hospital; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($hospa->name); ?></td>
										<td><?php echo e($hospa->location); ?></td>
										
										<td class="text-right">
											<div class="dropdown dropdown-action">
												<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
												<div class="dropdown-menu dropdown-menu-right">
													<a class="dropdown-item" href="<?php echo e(route('edit_hospital', ['id' => $hospa->id] )); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    
                                                     <form method="POST" action=" <?php echo e(route('delete_hospital', $hospa->id)); ?>" enctype="multipart/form-data">
                                                         <?php echo csrf_field(); ?>
													
                                                    <button class="dropdown-item" type="submit"  data-toggle="modal" data-target="#delete_appointment"><i class="fa fa-trash-o m-r-5"></i>  Delete </button>
                                                    </form>
												</div>
											</div>
										</td>
									</tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', ['activePage' => 'hospital'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dbmsystem\dbmsystemAPI\resources\views/hospital/hospitals.blade.php ENDPATH**/ ?>