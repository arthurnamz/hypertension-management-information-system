<?php $__env->startSection('content'); ?>

                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Edit Appointment</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form method="POST" action="<?php echo e(route('update_appointment', $Appointment->id)); ?>"  enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Patient Name</label>
                                        <select class="select" name="patient_id">
                                    
                                            <option value="<?php echo e($Appointment->patient_id); ?>"><?php echo e($Appointment->Patient->first_name); ?> <?php echo e($Appointment->Patient->last_name); ?></option>
                                            <?php $__currentLoopData = $Patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($patie->id); ?>"><?php echo e($patie->first_name); ?> <?php echo e($patie->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <!-- <input class="form-control" name="patient_id" type="text" value="APT-0001" readonly=""> -->
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Health Personel</label>
                                        <select class="select" name="employee_id">
                                           <option value="<?php echo e($Appointment->employee_id); ?>"><?php echo e($Appointment->Employee->first_name); ?> <?php echo e($Appointment->Employee->last_name); ?></option>
                                            <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->first_name); ?> <?php echo e($emp->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                           
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <div class="cal-icon">
                                            <input type="date" class="form-control" name="date" placeholder="yyyy-mm-dd" value="<?php echo e($Appointment->date); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Time</label>
                                        <div class="time-icon">
                                            <input type="time" class="form-control" name="time" value="<?php echo e($Appointment->time); ?>" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Message</label>
                                <textarea cols="30" rows="4" name="comment" class="form-control"><?php echo e($Appointment->comment); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label class="display-block">Appointment Status</label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status" id="product_active" value="attended" >
                                    <label class="form-check-label" for="product_active">
                                    Attended
                                    </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status" id="product_inactive" value="unattended">
                                    <label class="form-check-label" for="product_inactive">
                                    Unattended
                                    </label>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Update Appointment</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', ['activePage' => 'appointment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dbmsystem\dbmsystemAPI\resources\views/appointment/edit_appointment.blade.php ENDPATH**/ ?>