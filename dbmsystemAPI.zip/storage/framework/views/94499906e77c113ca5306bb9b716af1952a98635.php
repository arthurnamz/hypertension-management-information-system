<?php $__env->startSection('content'); ?>
                <div class="row">
                    <div class="col-sm-7 col-6">
                        <h4 class="page-title">My Profile</h4>
                    </div>

                    <div class="col-sm-5 col-6 text-right m-b-30">
                        <a href="<?php echo e(route('edit_patient', ['id' => $Patient->id] )); ?>" class="btn btn-primary btn-rounded"><i class="fa fa-plus"></i> Edit Profile</a>
                    </div>
                </div>
                <div class="card-box profile-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#"><img class="avatar" src="<?php echo e(asset('assets/img/doctor-03.jpg')); ?>" alt=""></a>
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 mb-0"><?php echo e($Patient -> first_name); ?> <?php echo e($Patient -> last_name); ?></h3>
                                                <small class="text-muted"><?php echo e($Patient -> role); ?> </small>
                                                <div class="staff-id">Patientloyee ID : SBP-0<?php echo e($Patient -> id); ?></div>
                                                <div class="staff-msg"><a href="chat.html" class="btn btn-primary">Send Message</a></div>
                                            </div>
                                        </div>
                                        <div class="col-md-7">
                                            <ul class="personal-info">
                                                <li>
                                                    <span class="title">Phone:</span>
                                                    <span class="text"><a href="#"><?php echo e($Patient -> phone_number); ?></a></span>
                                                </li>
                                                <li>
                                                    <span class="title">Email:</span>
                                                    <span class="text"><a href="mailto:<?php echo e($Patient -> email); ?>"><?php echo e($Patient -> email); ?></a></span>
                                                </li>
                                                <li>
                                                    <span class="title">Birthday:</span>
                                                    <span class="text"><?php echo e($Patient -> dob); ?></span>
                                                </li>
                                                <li>
                                                    <span class="title">Address:</span>
                                                    <span class="text"><?php echo e($Patient -> village); ?>, <?php echo e($Patient -> T_A); ?>, <?php echo e($Patient -> district); ?></span>
                                                </li>
                                                <li>
                                                    <span class="title">Gender:</span>
                                                    <span class="text"><?php echo e($Patient -> gender); ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
                <div class="profile-tabs">
                    <ul class="nav nav-tabs nav-tabs-bottom">
                        <li class="nav-item"><a class="nav-link active" href="#bp" data-toggle="tab">BP Tests</a></li>
                        <li class="nav-item"><a class="nav-link" href="#kidney" data-toggle="tab">Kidney Tests</a></li>
                        <li class="nav-item"><a class="nav-link" href="#urinal" data-toggle="tab">Urinalysis</a></li>
                         <li class="nav-item"><a class="nav-link" href="#glucose" data-toggle="tab">Glucose Test</a></li>
                         <li class="nav-item"><a class="nav-link" href="#chest" data-toggle="tab">Chest X-Ray</a></li>
                         <li class="nav-item"><a class="nav-link" href="#other" data-toggle="tab">Other Tests</a></li>
                         <li class="nav-item"><a class="nav-link" href="#allergy" data-toggle="tab">Allergies</a></li>
                         <li class="nav-item"><a class="nav-link" href="#treat" data-toggle="tab">Treatments</a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane show active" id="bp">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">BP Tests Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $BP_measurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Test was done by: <strong style="color: teal;"> <?php echo e($bp->Employee->first_name); ?> <?php echo e($bp->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Systolic : </strong><?php echo e($bp->systolic); ?></div>
                                                            <div><strong> diastolic : </strong><?php echo e($bp->diastolic); ?></div>
                                                            <div><strong> Pulse Rate : </strong><?php echo e($bp->pulse_rate); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;"><?php echo e(date('M j, Y', strtotime($bp->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="kidney">
                             <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Kidney Function Tests Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Kidney_Test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kidney): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Test was done by: <strong style="color: teal;"><?php echo e($kidney->Employee->first_name); ?> <?php echo e($kidney->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Result : </strong><?php echo e($kidney->results); ?></div>
                                                            <div><strong> Comment : </strong><?php echo e($kidney->comment); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;"> <?php echo e(date('M j, Y', strtotime($kidney->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="urinal">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Urinalysis Tests Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Urinalysis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $urine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Test was done by: <strong style="color: teal;"><?php echo e($urine->Employee->first_name); ?> <?php echo e($urine->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Result : </strong><?php echo e($urine->result); ?></div>
                                                            <div><strong> Comment : </strong><?php echo e($urine->comment); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;"> <?php echo e(date('M j, Y', strtotime($urine->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="glucose">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Glucose Tests Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Glucose_Test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $glucose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Test was done by: <strong style="color: teal;"><?php echo e($glucose->Employee->first_name); ?> <?php echo e($glucose->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Result : </strong><?php echo e($glucose->results); ?></div>
                                                            <div><strong> Comment : </strong><?php echo e($glucose->comment); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;"> <?php echo e(date('M j, Y', strtotime($glucose->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="chest">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Chest X-ray Tests Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Chest_xray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Test was done by: <strong style="color: teal;"><?php echo e($chest->Employee->first_name); ?> <?php echo e($chest->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Result : </strong><?php echo e($chest->results); ?></div>
                                                            <div><strong> Comment : </strong><?php echo e($chest->comment); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;"> <?php echo e(date('M j, Y', strtotime($chest->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="other">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Other Tests Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Other_Test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Test was done by: <strong style="color: teal;"><?php echo e($other->Employee->first_name); ?> <?php echo e($other->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Test Name : </strong><?php echo e($other->test_name); ?></div>
                                                            <div><strong> Result : </strong><?php echo e($other->results); ?></div>
                                                            <div><strong> Comment : </strong><?php echo e($other->comment); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;">  <?php echo e(date('M j, Y', strtotime($other->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="allergy">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Allergies Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Allergies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allergy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Diagnosed was done by: <strong style="color: teal;"><?php echo e($allergy->Employee->first_name); ?> <?php echo e($allergy->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Allergy Name : </strong><?php echo e($allergy->name); ?></div>
                                                            <div> <strong> Tested on  : </strong> <span style="color: green;">  <?php echo e(date('M j, Y', strtotime($allergy->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="treat">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-box">
                                        <h3 class="card-title">Treament Information</h3>
                                        <div class="experience-box">
                                            <ul class="experience-list">
                                                <?php $__currentLoopData = $Treatment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="experience-user">
                                                        <div class="before-circle"></div>
                                                    </div>
                                                    <div class="experience-content">
                                                        <div class="timeline-content">
                                                            <h4>Diagnosed was done by: <strong style="color: teal;"><?php echo e($treat->Employee->first_name); ?> <?php echo e($treat->Employee->last_name); ?></strong></h4>
                                                            <div><strong> Medicine Name : </strong><?php echo e($treat->name); ?></div>
                                                            <div><strong> Comment : </strong><?php echo e($treat->comment); ?></div>
                                                            <div> <strong> Treated on  : </strong> <span style="color: green;">  <?php echo e(date('M j, Y', strtotime($treat->created_at))); ?></span></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', ['activePage' => 'patient'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dbmsystem\dbmsystemAPI\resources\views/patient/profile.blade.php ENDPATH**/ ?>