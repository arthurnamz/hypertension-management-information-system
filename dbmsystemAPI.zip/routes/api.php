<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//routes for Contact

Route::get('contact', 'API\ContactController@index');
Route::get('contact/{id}', 'API\ContactController@show');
Route::post('contact', 'API\ContactController@store');
Route::put('contact/{id}', 'API\ContactController@update');
Route::delete('contact/{id}', 'API\ContactController@destroy');

//routes for Music

Route::get('music', 'API\MusicController@index');
Route::get('music/{id}', 'API\MusicController@show');
Route::post('music', 'API\MusicController@store');
Route::put('music/{id}', 'API\MusicController@update');
Route::delete('music/{id}', 'API\MusicController@destroy');

//routes for Namartist

Route::get('namartist', 'API\NamartistController@index');
Route::get('namartist/{id}', 'API\NamartistController@show');
Route::post('namartist', 'API\NamartistController@store');
Route::put('namartist/{id}', 'API\NamartistController@update');
Route::delete('namartist/{id}', 'API\NamartistController@destroy');

//routes for Testmonies

Route::get('testmonies', 'API\TestmoniesController@index');
Route::get('testmonies/{id}', 'API\TestmoniesController@show');
Route::post('testmonies', 'API\TestmoniesController@store');
Route::put('testmonies/{id}', 'API\TestmoniesController@update');
Route::delete('testmonies/{id}', 'API\TestmoniesController@destroy');

//routes for Projects

Route::get('project', 'API\ProjectController@index');
Route::get('project/{id}', 'API\ProjectController@show');
Route::post('project', 'API\ProjectController@store');
Route::put('project/{id}', 'API\ProjectController@update');
Route::delete('project/{id}', 'API\ProjectController@destroy');


//routes for Albums

Route::get('album', 'API\AlbumController@index');
Route::get('album/{id}', 'API\AlbumController@show');
Route::post('album', 'API\AlbumController@store');
Route::put('album/{id}', 'API\AlbumController@update');
Route::delete('album/{id}', 'API\AlbumController@destroy');

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
